using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Models;

namespace Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class AdmController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public AdmController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Método para autenticar o usuário administrador e gerar um token JWT.
        /// </summary>
        /// <param name="login"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequest login)
        {
            if (login.Username == "admin" && login.Password == "senha123")
            {
                var claims = new[]
                {
                new Claim(ClaimTypes.Role, "Admin"),
                new Claim(ClaimTypes.Name, login.Username)
            };

                var jwtSettings = _configuration.GetSection("Jwt").Get<JwtSettings>();
                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings.Key));

                var token = new JwtSecurityToken(
                    issuer: jwtSettings.Issuer,
                    audience: jwtSettings.Audience,
                    claims: claims,
                    expires: DateTime.UtcNow.AddHours(1),
                    signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256)
                );

                return Ok(new { token = new JwtSecurityTokenHandler().WriteToken(token) });
            }

            return Unauthorized("Login inválido");
        }
        /// <summary>
        /// Método para listar empresas.
        /// </summary>
        /// <param name="test"></param>
        /// <returns></returns>
        [Authorize]
        [HttpPost("ListarEmpresas")]
        public IActionResult ListarEmpresas([FromQuery] string test)
        {
            return Ok(new { message = "Lista de empresas", test });
        }
    }
}
